# Playlist creater from different years


## Functionality of the Music Player

-playlist creation of user favaraite song directly into their spotify account
## Usage

- Make sure you have Python installed in your system.
- Run Following command in the CMD.
 ```
  pip install Pyplaylist_spotify
  ```
## Example

 ```


## Run the following Script.
 ```
  python test.py
 ```


